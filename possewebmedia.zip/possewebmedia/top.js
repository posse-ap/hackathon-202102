// トップページのickup slide(まきこ)
var swiper = new Swiper('.swiper-container', {
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  loop: true,
  pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
});

// sessionのonclick処理(まきこ)
function display() {
  document.getElementById("morecontent").classList.add("can");
}